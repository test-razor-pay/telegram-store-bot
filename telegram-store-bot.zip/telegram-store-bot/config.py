BOT_TOKEN = "8222319323:AAEMYWTedLW1H-6pk_7zpeFNEFPWxbk-jJU"

ADMINS = [8053084391, 6695446010]

UPI_ID = "paytm.s1oppzf@pty"
UPI_NAME = "BANTI BHAIYA GAMING HUB"

MERCHANT_ID = "vupXaw32751713519005"
PAYMENT_API = "https://api.extracthub.fun/paytm-payment-gateway/index.php"

QR_EXPIRY_SECONDS = 180
